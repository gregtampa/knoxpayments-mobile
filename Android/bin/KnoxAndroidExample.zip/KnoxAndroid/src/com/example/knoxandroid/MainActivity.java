package com.example.knoxandroid;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_main);
        
        // This gets extra info from the Knox webview after a payment is complete
        Intent intent = this.getIntent();
        Bundle extras = intent.getExtras();
        
        // If this is true, the payment has already run and come to some end state
        if (extras!=null) {
        	// Getting the return URL
        	String uri = extras.get("url").toString();
        	
        	TextView confText = (TextView) findViewById(R.id.confirmation);
        	// If the transaction has been canceled by the user
        	if (uri.contains("transactionCanceled")) {
        		confText.setText("This transaction was canceled by the user.");
        	} else {
        		/* 
        		 * If the transaction was successful, let's return the transaction ID to the native app. 
        		 * This isn't necessary, but it could be good to show confirmation in the app.
        		 */
        		String[] split = uri.split("&");
                String last = split[split.length-1];
                
                // Sets the text in the confirmation box to payid=<something> 
                confText.setText(last);
        	}
        };
    }

    // Function for the Knox button to launch a new payment. This switches to the webViewActivity class and starts the payment with Knox.
    public void launchPayment(View view) {
    	Intent myIntent = new Intent(MainActivity.this, WebViewActivity.class);
    	MainActivity.this.startActivity(myIntent);
    }

}
